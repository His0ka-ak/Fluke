import { Component } from '@angular/core';
import { User } from './user';


 @Component({
    selector : 'register-user',
    templateUrl : './register-page.component.html'
 })

 export class AddUserComponent{
     users :User = new User();
   }

 


