export class User{
    constructor(public name?: string,
        public gender?: string,
        public mobile?: number,
        public email?: string,
        public password?: string,
        public address?: string) { }

}